# MITRE ATT&CK Mapping

| Technique ID | Technique Name            | Framework Module           |
|--------------|--------------------------|----------------------------|
| T1059        | Command and Scripting    | shell.py, agent shell task |
| T1113        | Screen Capture           | screenshot.py              |
| T1027        | Obfuscated Files/Info    | (future: encrypted comms)  |
| T1055        | Process Injection        | (future module)            |
| T1005        | Data from Local System   | file upload/download       |

Extend this mapping as you add more modules!